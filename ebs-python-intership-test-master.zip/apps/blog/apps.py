from django.apps import AppConfig


class BlogConfig(AppConfig):
    name = 'apps.blog'
